const sheetManager = require('./services/sheetManager');

async function debugExactRange() {
  try {
    const targetSheet = 'AUG25';
    console.log('Debugging EXACT RANGE B226:S248...');

    // Use the exact range you specified
    const pengeluaranData = await sheetManager.getSheetData(targetSheet, 'B226:S248');
    
    console.log('\n=== EXACT RANGE B226:S248 ===');
    for (let i = 0; i < pengeluaranData.length; i++) {
      const row = pengeluaranData[i];
      console.log(`Row ${i + 226}:`, row);
    }
    
    console.log('\n=== CHECKING COLUMN MAPPING ===');
    console.log('Expected mapping for PENGELUARAN section:');
    console.log('- Column B (index 0): ?');
    console.log('- Column C (index 1): Date');
    console.log('- Column D (index 2): Description'); 
    console.log('- Column M (index 11): Amount');
    
    console.log('\nActual data structure:');
    pengeluaranData.forEach((row, index) => {
      if (row && row.some(cell => cell && cell.toString().trim() !== '')) {
        console.log(`Row ${index + 226}:`);
        console.log(`  [0] B: "${row[0]}"`);
        console.log(`  [1] C: "${row[1]}"`);
        console.log(`  [2] D: "${row[2]}"`);
        console.log(`  [11] M: "${row[11]}"`);
        
        // Check if this looks like the "04" row
        if (row[0] === '04' || row[1] === '04') {
          console.log(`  ✅ FOUND "04" ROW!`);
        }
      }
    });

  } catch (error) {
    console.error('Error:', error);
  }
}

debugExactRange();