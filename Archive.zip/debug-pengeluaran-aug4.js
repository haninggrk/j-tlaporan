const sheetManager = require('./services/sheetManager');

async function debugPengeluaranAug4() {
  try {
    const targetSheet = 'AUG25';
    console.log('Debugging PENGELUARAN for August 4, 2025...');

    // Read pengeluaran data from the specified range
    const pengeluaranData = await sheetManager.getSheetData(targetSheet, 'B226:S248');
    
    console.log('\n=== RAW PENGELUARAN DATA (B226:S248) ===');
    for (let i = 0; i < pengeluaranData.length; i++) {
      const row = pengeluaranData[i];
      if (row && row.some(cell => cell && cell.toString().trim() !== '')) {
        console.log(`Row ${i + 226}:`, row);
      }
    }
    
    console.log('\n=== LOOKING FOR DATE "4" ===');
    const targetDay = '4';
    
    let totalPengeluaran = 0;
    let pengeluaranWithoutPrice = [];
    let foundItems = [];
    
    pengeluaranData.forEach((row, index) => {
      const dateValue = row[1]; // Column C (index 1)
      const description = row[2]; // Column D (index 2)
      const amount = row[11]; // Column M (index 11)
      
      // Debug every row that has a date
      if (dateValue && dateValue.toString().trim() !== '') {
        console.log(`Row ${index + 226} - Date: "${dateValue}", Desc: "${description}", Amount: "${amount}"`);
      }
      
      // Check if this row matches target date
      if (dateValue && dateValue.toString() === targetDay) {
        console.log(`✅ FOUND MATCH - Row ${index + 226}:`, {
          date: dateValue,
          description: description,
          amount: amount,
          fullRow: row
        });
        
        foundItems.push({
          row: index + 226,
          date: dateValue,
          description: description,
          amount: amount
        });
        
        if (description && description.toString().trim() !== '') {
          if (amount && amount.toString().trim() !== '') {
            const amountValue = parseFloat(amount.toString().replace(/[^\d.-]/g, ''));
            totalPengeluaran += amountValue;
          } else {
            pengeluaranWithoutPrice.push(description.toString().trim());
          }
        }
      }
    });
    
    console.log('\n=== SUMMARY ===');
    console.log(`Found ${foundItems.length} items for date "${targetDay}"`);
    console.log('Items found:', foundItems);
    console.log(`Total pengeluaran: ${totalPengeluaran}`);
    console.log('Items without price:', pengeluaranWithoutPrice);

  } catch (error) {
    console.error('Error:', error);
  }
}

debugPengeluaranAug4();